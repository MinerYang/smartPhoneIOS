//
//  Main.swift
//  InventoryMng
//
//  Created by MINER YANG on 11/1/20.
//  Copyright © 2020 MINER YANG. All rights reserved.
//

import Foundation
import UIKit

class Role {
    var name  = ""
    var photo : UIImage?
    //var btn : UIButton?
    
    init?(name : String, photo:UIImage?){
        guard !name.isEmpty else{
            return nil
        }
        self.name = name
        self.photo = photo
    }
}


