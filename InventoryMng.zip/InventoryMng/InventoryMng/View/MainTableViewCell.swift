//
//  MainTableViewCell.swift
//  InventoryMng
//
//  Created by MINER YANG on 11/1/20.
//  Copyright © 2020 MINER YANG. All rights reserved.
//

import UIKit

class MainTableViewCell: UITableViewCell {

    @IBOutlet weak var roleBtn: UIButton!
    @IBOutlet weak var photoImg: UIImageView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
