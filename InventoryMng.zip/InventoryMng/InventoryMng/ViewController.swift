//
//  ViewController.swift
//  InventoryMng
//
//  Created by MINER YANG on 11/1/20.
//  Copyright © 2020 MINER YANG. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

