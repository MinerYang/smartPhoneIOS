//
//  MainTableViewController.swift
//  InventoryMng
//
//  Created by MINER YANG on 11/1/20.
//  Copyright © 2020 MINER YANG. All rights reserved.
//

import UIKit

class MainTableViewController: UITableViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        
        loadMain()

        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false

        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        // self.navigationItem.rightBarButtonItem = self.editButtonItem
    }

    // MARK: - Table view data source
    var roles = [Role]()
    private func loadMain(){
        let photo1 = UIImage(named: "role1")
        let photo2 = UIImage(named: "role2")
        let photo3 = UIImage(named: "role3")
        let photo4 = UIImage(named: "role4")
        let photo5 = UIImage(named: "role5")
        
        guard let role1 = Role(name: "Supplier", photo: photo1) else {
            fatalError("Unable to instantiate meal1")
        }
        guard let role2 = Role(name: "Customer", photo: photo2) else {
            fatalError("Unable to instantiate meal1")
        }
        guard let role3 = Role(name: "Product", photo: photo3) else {
            fatalError("Unable to instantiate meal1")
        }
        guard let role4 = Role(name: "Department", photo: photo4) else {
            fatalError("Unable to instantiate meal1")
        }
        guard let role5 = Role(name: "Category", photo: photo5) else {
            fatalError("Unable to instantiate meal1")
        }
        
        roles += [role1,role2,role3,role4,role5]
    }
    

    override func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return roles.count
    }

    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cellIdentifier = "MainTableViewCell"
        guard let cell = tableView.dequeueReusableCell(withIdentifier: cellIdentifier, for: indexPath) as? MainTableViewCell else{
            fatalError("The dequeued cell is not an instance of MealTableViewCell.")
        }

        // Configure the cell...
        let role = roles[indexPath.row]
        cell.roleBtn.setTitle(role.name, for: .normal)
        cell.photoImg.image = role.photo
        return cell
    }
    

    /*
    // Override to support conditional editing of the table view.
    override func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the specified item to be editable.
        return true
    }
    */

    /*
    // Override to support editing the table view.
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            // Delete the row from the data source
            tableView.deleteRows(at: [indexPath], with: .fade)
        } else if editingStyle == .insert {
            // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
        }    
    }
    */

    /*
    // Override to support rearranging the table view.
    override func tableView(_ tableView: UITableView, moveRowAt fromIndexPath: IndexPath, to: IndexPath) {

    }
    */

    /*
    // Override to support conditional rearranging of the table view.
    override func tableView(_ tableView: UITableView, canMoveRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the item to be re-orderable.
        return true
    }
    */

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
